package controller;

import entity.User;
import repository.UserRepository;
import service.UserService;
import utill.Utill;

import java.util.List;

public class Controller {
    public void mainController(){
        UserService userService=new UserService();
        UserRepository userRepository=new UserRepository();
        String menu= """
                0 - exit
                1 - sign-in
                2 - sign-up
                3 - show users
                """;
        while (true) {
            System.out.println(menu);
            switch (Utill.intScanner.nextInt()){
                case 0 -> {
                    System.out.println("Good bye ... ");
                    return;
                }
                case 1 -> userService.signIn();
                case 2 -> userService.signUp();
                case 3 -> {
                    List<User> allUsers = userRepository.getAllUsers();
                    for (int i = 0; i < allUsers.size(); i++) {
                        System.out.println(allUsers.get(i));

                    }

                }

            }
        }
    }
}
