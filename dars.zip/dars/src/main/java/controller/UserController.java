package controller;

import entity.User;

public class UserController {
    public void userController(User user){
        String menu= """
                0 - exit
                1 show info
                2 edit info
                3 delete account
                """;
    }
}
