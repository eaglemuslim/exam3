package entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.UUID;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class User {
    private String id = UUID.randomUUID().toString();
    private String name;
    private String login;
    private String password;
    private boolean isActivated;

    public User(String name, String login, String password) {
        this.name = name;
        this.login = login;
        this.password = password;
        this.isActivated = true;
    }
}
