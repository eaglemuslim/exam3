import controller.Controller;

public class Demo {
    public static void main(String[] args) throws Exception {
        System.out.println(Math.ceil(1.3));
//        URL url=new URL("https://nbu.uz/uz/exchange-rates/json/");
//        URLConnection urlConnection = url.openConnection();
//        InputStream inputStream = urlConnection.getInputStream();
//        Gson gson = new Gson();
//        List<Currency> currencies = gson.fromJson(new InputStreamReader(inputStream),new TypeToken<List<Currency>>(){}.getType());
//        currencies.forEach(currency -> System.out.println(currency));
//        Controller  controller=new Controller();
//        controller.mainController();
    }
}
