package service;

import utill.Utill;

import javax.mail.*;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Properties;

public class GmailService {
    public void sendMessage(String text,String gmail){
        Properties properties=System.getProperties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(Utill.gmail, "yonunskzbyabufpy");
            }
        });

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(Utill.gmail));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(gmail));

            // Set Subject: header field
            message.setSubject("This email generated automatically, please don't reply!");

            // Now set the actual message
            message.setContent("<p> your code is <strong>"+text+"</strong> please don't share this code to anyone</p>","text/html");

            // Send message
            Transport.send(message);
        } catch (MessagingException mex) {
//            mex.printStackTrace();
        }
    }
}
