package service;

import controller.UserController;
import entity.User;
import repository.UserRepository;
import utill.Utill;

import java.time.LocalTime;
import java.util.Objects;

public class UserService {
    UserRepository userRepository=new UserRepository();
    GmailService gmailService=new GmailService();
    UserController userController=new UserController();

    public void signUp(){
        System.out.println("name");
        String name = Utill.strScanner.nextLine();
        System.out.println("login");
        String login = Utill.strScanner.nextLine();
        boolean isPasswordChecked = sendCode(login);
        if (!isPasswordChecked){
            System.out.println("authentication failed");
            return;
        }else {
            System.out.println("success");

        }

        System.out.println("password");
        String password = Utill.strScanner.nextLine();
        if (userRepository.isExist(login)){
            System.out.println("login exist");
            return;
        }
        User user=new User(name,login,password);

        userRepository.addUser(user);

    }

    private boolean sendCode(String gmail) {
        String number="0123456789abcdef";
        String password="";
        String userPassword="";
        for (int i = 0; i < 6; i++) {
            password+=number.charAt((int)(Math.random()*16));
        }
        gmailService.sendMessage(password,gmail);
        LocalTime endTime = LocalTime.now().plusSeconds(20);
        while (true) {
            System.out.println("parolni tasdiqlang");
            userPassword = Utill.strScanner.nextLine();
            if (LocalTime.now().isAfter(endTime)) {
                System.out.println("time expired");
                break;
            }

            if (Objects.equals(password, userPassword)) {
                return true;
            }
        }
        return false;
    }



    public void signIn() {
        System.out.println("login");
        String login = Utill.strScanner.nextLine();
        System.out.println("password");
        String password = Utill.strScanner.nextLine();
        User user = userRepository.getUser(login, password);
        if (user==null){
            System.out.println("User not found");
            return;
        }
        userController.userController(user);

        //bu yerda user controller bo'lishi mumkin edi.


    }
}
